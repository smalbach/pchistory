@extends('companies/layout')




@section('content')

<p class="description bg-grayLighter padding200">
<h1>Pc History</h1>
<h2>{{$company->name}}</h2>











@stop


