@extends('layout')




@section('content')

<p class="description bg-grayLighter padding200">
<h1>Hire me</h1>
<h2>Aplicacion clase de mejorandola</h2>

<a  class="button success" href="{{ route('sign_up') }}">postulate</a>

</p>


<h1 >Ultimos Candidatos</h1>



@stop


