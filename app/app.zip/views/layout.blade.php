<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="{{ asset('yeti/css/bootstrap.css') }}">

    <link rel="stylesheet" href="{{ asset('yeti/css/ui/jquery-ui.css') }}">


    <script src="{{ asset('yeti/js/jquery/jquery-1.11.1.min.js') }}"></script>
    <script src="{{ asset('yeti/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('yeti/js/ui/jquery-ui-1.10.4.js') }}"></script>
    <script src="{{ asset('yeti/js/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('yeti/js/lenguaje_validacion.js') }}"></script>


    <style>
        table tr{
            cursor: pointer;
        }

    </style>

</head>
<body class="metro">

<div class="navbar navbar-inverse">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-inverse-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="{{ route('home')}}">PC History</a>
    </div>
    <div class="navbar-collapse collapse navbar-inverse-collapse">



    </div>
</div>







<div class="container">
    @yield('content')
</div>





</body>
</html>