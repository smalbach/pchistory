<?php
/**
 * Created by PhpStorm.
 * User: Aikon
 * Date: 7/06/14
 * Time: 9:23
 */

namespace PcHistory\Entities;


class User_support extends \Eloquent {

} 