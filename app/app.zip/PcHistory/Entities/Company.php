<?php namespace PcHistory\Entities;



class Company   extends \Eloquent {

    protected $fillable = [];



} 