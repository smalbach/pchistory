<?php
/**
 * Created by PhpStorm.
 * User: Aikon
 * Date: 28/05/14
 * Time: 14:12
 */

namespace PcHistory\Entities;


class Suport extends \Eloquent {

} 