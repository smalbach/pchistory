<?php 

return [
	'job_types'=>[
		'full'		=>"Tiempo Completo",
		'partial'	=>"Parcial",
		'freelance'	=>"Freelance"


	]


];



 ?>